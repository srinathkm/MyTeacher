import streamlit as st
import time

# --- CONFIGURATION & PERSONA ---
st.set_page_config(
    page_title="MyTeacher | AI Kannada Tutor", 
    layout="wide", 
    initial_sidebar_state="expanded"
)

def apply_styles():
    st.markdown("""
        <style>
        .main { background-color: #FDFCFB; }
        .stChatMessage { border-radius: 15px; margin-bottom: 10px; }
        .vocab-card { 
            background-color: #FFF9C4; 
            padding: 15px; 
            border-radius: 10px; 
            border-left: 5px solid #FBC02D;
            margin-bottom: 10px;
        }
        .teacher-prompt {
            font-style: italic;
            color: #2E7D32;
            font-weight: bold;
            font-size: 1.1rem;
        }
        .kannada-text {
            font-size: 1.4rem;
            line-height: 1.8;
            color: #1A237E;
            background-color: #E8EAF6;
            padding: 15px;
            border-radius: 10px;
        }
        </style>
    """, unsafe_allow_html=True)

# --- CORE LOGIC (POC DEMONSTRATOR DATA) ---
def process_lesson():
    # Demonstrator data for Dr. Rajendra Prasad Lesson
    return {
        "title": "Lesson 1: Dr. Rajendra Prasad",
        "sections": [
            {
                "kannada": "ಭಾರತದ ಪ್ರಥಮ ರಾಷ್ಟ್ರಪತಿಗಳಾದ ಡಾ. ರಾಜೇಂದ್ರ ಪ್ರಸಾದ್ ಅವರು ಸರಳತೆ ಮತ್ತು ಸಜ್ಜನಿಕೆಗೆ ಹೆಸರಾದವರು.",
                "explanation": "Dr. Rajendra Prasad was India's first President. He was famous because he was very simple and a very good human being.",
                "context": "Think of a leader who acts like a friend. Even though he was the most important person in India, he lived very simply without any show-off.",
                "vocab": [
                    {"word": "ಸರಳತೆ (Saralate)", "meaning": "Simplicity", "usage": "Living without showing off."},
                    {"word": "ಸಜ್ಜನಿಕೆ (Sajjanike)", "meaning": "Gentlemanliness", "usage": "Being noble and kind to everyone."}
                ]
            }
        ]
    }

# --- UI LAYOUT ---
def main():
    apply_styles()
    
    with st.sidebar:
        st.title("👨‍🏫 MyTeacher")
        st.info("**Student Profile:** Age 10-16\\n**Dialect:** Bengaluru School Standard")
        st.divider()
        st.write("""
        ### How to use:
        1. Upload your textbook photo.
        2. Listen to the Teacher's explanation.
        3. Add words to your Word Bank.
        4. Reflect on the lesson.
        """)
        st.divider()
        if st.button("📥 Export Word Bank (PDF)"):
            st.toast("Feature coming soon: Generating PDF...")

    st.title("Welcome to Your Kannada Classroom")
    
    # Input Area
    input_col1, input_col2 = st.columns([2, 1])
    with input_col1:
        doc_input = st.file_uploader("Upload Lesson Screenshot (e.g., Dr. Rajendra Prasad Lesson)", type=["png", "jpg", "jpeg", "pdf"])
    with input_col2:
        lang = st.selectbox("Explain to me in:", ["English", "Hindi"])

    if st.button("🚀 Start Learning"):
        lesson = process_lesson()
        
        st.divider()
        st.header(f"📖 {lesson['title']}")
        
        col_left, col_right = st.columns([3, 2])
        
        with col_left:
            for idx, section in enumerate(lesson["sections"]):
                st.markdown(f'<div class="kannada-text">{section["kannada"]}</div>', unsafe_allow_html=True)
                
                with st.chat_message("assistant", avatar="👨‍🏫"):
                    st.write(f"**Teacher Says:** {section['explanation']}")
                    st.write(f"💡 **Why this matters:** {section['context']}")
                    
                    st.audio("https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3")
                    st.caption("🔊 Paced at 0.8x speed for clear understanding.")

        with col_right:
            st.write("### 📒 Word Meanings (Alar.ink)")
            for item in section["vocab"]:
                st.markdown(f"""
                    <div class="vocab-card">
                        <b>{item['word']}</b><br>
                        <i>{item['meaning']}</i><br>
                        <small>{item['usage']}</small>
                    </div>
                """, unsafe_allow_html=True)

        st.divider()
        st.write("### 🤔 Let's Think Together")
        st.markdown('<p class="teacher-prompt">Dr. Prasad was the President but lived like a common man. Can you think of a time when you were simple even though you achieved something big?</p>', unsafe_allow_html=True)
        
        review_input = st.text_area("Your thoughts (helps you remember the lesson holistically):")
        if st.button("Submit My Thoughts"):
            if review_input:
                st.balloons()
                st.success("Wonderful reflection! This helps you understand the character better than just memorizing words.")
            else:
                st.warning("Try writing just one sentence about your thoughts!")

if __name__ == "__main__":
    main()
