# MyTeacher (V1.0 Prototype)

**MyTeacher** is an AI-powered educational companion for non-native Kannada speakers (ages 10–16). It focuses on **contextual understanding** rather than rote translation.

## 🚀 Getting Started in GitHub Codespaces

1. **Open this Repo** in GitHub.
2. Click the green **"<> Code"** button, select the **Codespaces** tab, and click **Create codespace on main**.
3. In the terminal, run the application:
   ```bash
   streamlit run app.py
   ```
4. Click **Open in Browser** to see the UI.

## 🛠 Project Principles
- **Holistic Review:** Students write/speak summaries to internalize concepts.
- **Contextual Dictionary:** Integrates the spirit of Alar.ink for word usage.
- **Bengaluru Dialect:** Focuses on standard school-level Kannada.
